<?php

namespace Icinga\Module\Director\Clicommands;

use Icinga\Module\Director\Cli\ObjectsCommand;

/**
 * Manage Icinga Hostgroups
 *
 * Use this command to list Icinga Hostgroup objects
 */
class HostgroupsCommand extends ObjectsCommand
{
}
