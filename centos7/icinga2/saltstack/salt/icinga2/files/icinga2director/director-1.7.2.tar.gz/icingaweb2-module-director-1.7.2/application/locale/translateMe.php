<?php

// Dummy strings helping the translation module

translate('up');
translate('down');
translate('unreachable');
translate('pending');
translate('ok');
translate('warning');
translate('critical');
translate('unknown');
