<?php

namespace Icinga\Module\Director\Dashboard\Dashlet;

class ServiceChoicesDashlet extends ChoicesDashlet
{
}
