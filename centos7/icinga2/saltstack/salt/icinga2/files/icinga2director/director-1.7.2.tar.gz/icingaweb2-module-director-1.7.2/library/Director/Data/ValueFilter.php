<?php

// TODO: move elsewhere, this is for forms
namespace Icinga\Module\Director\Data;

use Zend_Filter_Interface;

interface ValueFilter extends Zend_Filter_Interface
{
}
