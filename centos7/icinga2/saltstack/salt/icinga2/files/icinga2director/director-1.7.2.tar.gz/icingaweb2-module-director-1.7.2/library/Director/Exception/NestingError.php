<?php

namespace Icinga\Module\Director\Exception;

use Icinga\Exception\IcingaException;

class NestingError extends IcingaException
{
}
