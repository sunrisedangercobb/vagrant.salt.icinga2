<?php

namespace Icinga\Module\Director\Objects;

class HostGroupMembershipResolver extends GroupMembershipResolver
{
    protected $type = 'host';
}
