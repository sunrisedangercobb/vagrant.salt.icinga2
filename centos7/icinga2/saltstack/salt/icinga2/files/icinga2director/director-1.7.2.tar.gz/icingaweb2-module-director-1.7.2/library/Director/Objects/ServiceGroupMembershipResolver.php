<?php

namespace Icinga\Module\Director\Objects;

class ServiceGroupMembershipResolver extends GroupMembershipResolver
{
    protected $type = 'service';
}
